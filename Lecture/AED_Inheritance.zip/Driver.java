package edu.neu.aed;

public class Driver {

	public static void main(String[] args) {
		System.out.println("Project1 Driver executing main()...");
		
		ExplosionController.demo();
//		ExplosionController.demo2();
//		GunShot.demo();
		System.out.println("Project1 Driver executing main() done!");
	}

}
