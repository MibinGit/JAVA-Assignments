package edu.neu.aed;

public abstract class AbstractExplosionAPI {

	public abstract void explode();	// abstract method for API
}
