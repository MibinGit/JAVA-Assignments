package edu.neu.aed;

public abstract class AbstractExplosionFactoryAPI {
	public abstract Explosion getObject();

}
