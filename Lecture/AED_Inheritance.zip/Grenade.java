package edu.neu.aed;

public class Grenade extends Explosion {
	public void explode() {
		System.out.println("(SPLATTER)");
	}
}
