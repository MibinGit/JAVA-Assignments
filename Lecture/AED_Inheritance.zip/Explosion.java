package edu.neu.aed;

/**
 * Explosion Super class
 * @author danielgmp
 *
 */
public class Explosion extends AbstractExplosionAPI {
	public void explode() {
		System.out.println("EXPLODE!!!");
	}
}
