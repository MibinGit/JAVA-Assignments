/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UserInterface.Customer;

import Business.*;
import UserInterface.AirlinerManager.ManageAirplaneJPanel;
import java.awt.CardLayout;
import java.awt.Component;
import java.text.SimpleDateFormat;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author minjian
 */

public class SeatChooseJPanel extends javax.swing.JPanel {

    /**
     * Creates new form SeatChooseJPanel
     */
    
    JPanel rightPanel;
    Customer customer;
    Flight flight;
    OrderList orderlist;
    
    public SeatChooseJPanel(JPanel rp,Customer c,Flight f) {
        initComponents();
        rightPanel = rp;
        customer = c;
        flight = f;
        
        txtfltNum.setText(flight.getFlightNum());
        txtRemainSeat.setText(String.valueOf(flight.getSeatAssignment().getRemainSeat()));
        
        populate();
        
        
        
        
    }
    
    public void populate(){
        int[][] arr = flight.getSeatAssignment().getArrSeat();
       
        DefaultTableModel dtm = (DefaultTableModel)tblSeat.getModel();
        dtm.setRowCount(0);
       
        for(int a=0;a<arr.length;a++){
            String[] ar = new String [7];
            
            for(int i=0;i<arr[a].length;i++){
                
                if(arr[a][i] == 1){
                    ar[0] = (String.valueOf(a+1));
                    ar[i+1] = "X"; 
                    for(Order o : customer.getOrderList().getOrderList()){
                        if(o.getSeat().getRow() == a+1 && o.getSeat().getColumn() == i+1){
                            ar[i+1] = "Booked";
                        }
                    }
                }else{
                    ar[0] = (String.valueOf(a+1));    
                }
            }
                        
            dtm.addRow(ar);
        }
        txtRemainSeat.setText(String.valueOf(flight.getSeatAssignment().getRemainSeat()));
    }
    
    
//    DefaultTableModel dtm = (DefaultTableModel)tblOrder.getModel();
//        for(int i = rowCount - 1; i >=0; i--) {
//            dtm.removeRow(i);
//        }
//        
//            for(Order o : customer.getOrderList().getOrderList()){
//                    
//                    SimpleDateFormat ymd =   new SimpleDateFormat( "yyyy-MM-dd" );
//                    SimpleDateFormat hm =   new SimpleDateFormat( "HH:mm" );
//        
//            Object row[] = new Object[dtm.getColumnCount()];
//            row[0] = o;
//            row[1] = o.getFlight().getFlightNum();
//            row[2] = o.getFlight().getAirplane().getAirliner().getAirlinerName();
//            row[3] = ymd.format(o.getFlight().getDepDate());
//            row[4] = hm.format(o.getFlight().getDepDate());
//            row[5] = ymd.format(o.getFlight().getArrDate());
//            row[6] = hm.format(o.getFlight().getArrDate());
//            row[7] = o.getFlight().getDepLoc();
//            row[8] = o.getFlight().getArrLoc();
//            row[9] = o.getSeat().getSeatPosition();
//            
//            dtm.addRow(row);
    
//    public void populate(){
//        
//        
//        
//        rowComboBox.removeAllItems();
//        columnComboBox.removeAllItems();
//        
//        int sum = 0;
//        int[][] arr1 = flight.getSeatAssignment().getArrSeat();
//        for (int a=0; a<arr1.length; a++){
//            for(int i=0; i<arr1[a].length; i++){
//               sum  = sum + arr1[a][i];
//            }
//            if(sum != 25){
//                   sum =0;
//                   rowComboBox.addItem(a+1);        
//            }
//        }
//    
//    
//        int sum1 = 0;
//       
//        int row = rowComboBox.getSelectedIndex();
//        if(sum1 != 6){
//            for(int a=0;a<arr1.length; a++){
//                sum1 = sum1 + arr1[a][0];
//            }
//            columnComboBox.addItem("A"); 
//            sum1 = 0;
//        }
//        
//        if(sum1 != 6){
//            for(int a=0;a<arr1.length; a++){
//                sum1 = sum1 + arr1[a][1];
//            }
//            columnComboBox.addItem("B"); 
//            sum1 = 0;
//        }
//            
//        if(sum1 != 6){
//            for(int a=0;a<arr1.length; a++){
//                sum1 = sum1 + arr1[a][2];
//            }
//            columnComboBox.addItem("C"); 
//            sum1 = 0;
//        } 
//        
//        if(sum1 != 6){
//            for(int a=0;a<arr1.length; a++){
//                sum1 = sum1 + arr1[a][3];
//            }
//            columnComboBox.addItem("D"); 
//            sum1 = 0;
//        }   
//        
//        if(sum1 != 6){
//            for(int a=0;a<arr1.length; a++){
//                sum1 = sum1 + arr1[a][4];
//            }
//            columnComboBox.addItem("E"); 
//            sum1 = 0;
//        }   
//        
//        if(sum1 != 6){
//            for(int a=0;a<arr1.length; a++){
//                sum1 = sum1 + arr1[a][5];
//            }
//            columnComboBox.addItem("F"); 
//            sum1 = 0;
//        }   
//    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        rowComboBox = new javax.swing.JComboBox();
        jLabel6 = new javax.swing.JLabel();
        columnComboBox = new javax.swing.JComboBox();
        txtfltNum = new javax.swing.JTextField();
        txtRemainSeat = new javax.swing.JTextField();
        btnBook = new javax.swing.JButton();
        btnBack = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblSeat = new javax.swing.JTable();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();

        jLabel1.setText("Choose your Seat:");

        jLabel2.setText("Flight Number:");

        jLabel3.setText("Seat Remianing:");

        jLabel4.setFont(new java.awt.Font("Lucida Grande", 0, 24)); // NOI18N
        jLabel4.setText("Seat Choose");

        jLabel5.setText("Row:");

        rowComboBox.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "1","2","3","4","5","6","7","8","9","10",
            "11","12","13","14","15","16","17","18","19","20",
            "21","22","23","24","25"                  }));
rowComboBox.addActionListener(new java.awt.event.ActionListener() {
    public void actionPerformed(java.awt.event.ActionEvent evt) {
        rowComboBoxActionPerformed(evt);
    }
    });

    jLabel6.setText("Column:");

    columnComboBox.setModel(new javax.swing.DefaultComboBoxModel(new String[] {"A","B","C","D","E","F"}));
    columnComboBox.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            columnComboBoxActionPerformed(evt);
        }
    });

    txtfltNum.setEditable(false);
    txtfltNum.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            txtfltNumActionPerformed(evt);
        }
    });

    txtRemainSeat.setEditable(false);

    btnBook.setText("Place Order");
    btnBook.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            btnBookActionPerformed(evt);
        }
    });

    btnBack.setText("<<Back");
    btnBack.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            btnBackActionPerformed(evt);
        }
    });

    tblSeat.setModel(new javax.swing.table.DefaultTableModel(
        new Object [][] {
            {"1", " ", null, null, null, null, null},
            {"2", null, null, null, null, null, null},
            {"3", null, null, null, null, null, null},
            {"4", null, null, null, null, null, null},
            {"5", null, null, null, null, null, null},
            {"6", null, null, null, null, null, null},
            {"7", null, null, null, null, null, null},
            {"8", null, null, null, null, null, null},
            {"9", null, null, null, null, null, null},
            {"10", null, null, null, null, null, null},
            {"11", null, null, null, null, null, null},
            {"12", null, null, null, null, null, null},
            {"13", null, null, null, null, null, null},
            {"14", null, null, null, null, null, null},
            {"15", null, null, null, null, null, null},
            {"16", null, null, null, null, null, null},
            {"17", null, null, null, null, null, null},
            {"18", null, null, null, null, null, null},
            {"19", null, null, null, null, null, null},
            {"20", null, null, null, null, null, null},
            {"21", null, null, null, null, null, null},
            {"22", null, null, null, null, null, null},
            {"23", null, null, null, null, null, null},
            {"24", null, null, null, null, null, null},
            {"25", null, null, null, null, null, null}
        },
        new String [] {
            "Row Num", "A", "B", "C", "D", "E", "F"
        }
    ) {
        boolean[] canEdit = new boolean [] {
            false, false, false, false, false, false, false
        };

        public boolean isCellEditable(int rowIndex, int columnIndex) {
            return canEdit [columnIndex];
        }
    });
    jScrollPane1.setViewportView(tblSeat);

    jLabel7.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
    jLabel7.setText("Seat Assignment");

    jLabel8.setText("A-Left Window");

    jLabel9.setText("B-Left Middle");

    jLabel10.setText("C-Left Aisle");

    jLabel11.setText("D-Right Aisle");

    jLabel12.setText("E-Right Middle");

    jLabel13.setText("F-Right Window");

    jLabel14.setText("X-Booked By Other Customer");

    javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
    this.setLayout(layout);
    layout.setHorizontalGroup(
        layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(layout.createSequentialGroup()
            .addGap(61, 61, 61)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jLabel4)
                .addGroup(layout.createSequentialGroup()
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel6)
                        .addComponent(jLabel5)
                        .addComponent(jLabel2)
                        .addComponent(jLabel3)
                        .addComponent(jLabel1))
                    .addGap(41, 41, 41)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(txtfltNum, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(txtRemainSeat, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(rowComboBox, 0, 150, Short.MAX_VALUE)
                        .addComponent(columnComboBox, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGroup(layout.createSequentialGroup()
                    .addComponent(btnBack, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(59, 59, 59)
                    .addComponent(btnBook, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)))
            .addGap(18, 18, 18)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 466, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(40, 40, 40)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel8)
                        .addComponent(jLabel9)
                        .addComponent(jLabel10)
                        .addComponent(jLabel11)
                        .addComponent(jLabel12)
                        .addComponent(jLabel13)
                        .addComponent(jLabel14)))
                .addComponent(jLabel7))
            .addContainerGap(72, Short.MAX_VALUE))
    );
    layout.setVerticalGroup(
        layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(layout.createSequentialGroup()
            .addGap(38, 38, 38)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                .addComponent(jLabel4)
                .addComponent(jLabel7))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(28, 28, 28)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel2)
                        .addComponent(txtfltNum, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(18, 18, 18)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel3)
                        .addComponent(txtRemainSeat, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(18, 18, 18)
                    .addComponent(jLabel1)
                    .addGap(18, 18, 18)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel5)
                        .addComponent(rowComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(18, 18, 18)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel6)
                        .addComponent(columnComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(62, 62, 62)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnBook)
                        .addComponent(btnBack)))
                .addGroup(layout.createSequentialGroup()
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(layout.createSequentialGroup()
                            .addGap(103, 103, 103)
                            .addComponent(jLabel8)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jLabel9)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jLabel10)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jLabel11)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jLabel12)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jLabel13)
                            .addGap(18, 18, 18)
                            .addComponent(jLabel14)))))
            .addContainerGap(106, Short.MAX_VALUE))
    );
    }// </editor-fold>//GEN-END:initComponents

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
        // TODO add your handling code here:
        backAction();
    }//GEN-LAST:event_btnBackActionPerformed

    private void columnComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_columnComboBoxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_columnComboBoxActionPerformed

    private void rowComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rowComboBoxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rowComboBoxActionPerformed

    private void btnBookActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBookActionPerformed
        // TODO add your handling code here:
        
        int[][] arr = flight.getSeatAssignment().getArrSeat();
        if(arr[rowComboBox.getSelectedIndex()][columnComboBox.getSelectedIndex()] == 1){
            JOptionPane.showMessageDialog(null,"The seat has been booked.");
            return;
        }
        Order o = customer.getOrderList().addOrder();
        
        
        
        o.setCustomer(customer);
        o.setFlight(flight);
        o.setSeat(rowComboBox.getSelectedIndex(), columnComboBox.getSelectedIndex(),(String)columnComboBox.getSelectedItem());
        o.getFlight().getCtmDir().add(customer);
        //Seat s = o.getCustomer().getFlight().getSeatAssignment().addSeat();
        
        int r = o.getFlight().getSeatAssignment().getRemainSeat();
            r = r-1;
        
        //o.setOrderNum("1");
         //s.setSeatPosition(String.valueOf(rowComboBox.getSelectedItem())+(String)lineComboBox.getSelectedItem());
        o.getFlight().getSeatAssignment().setRemainSeat(r);
        o.getFlight().getSeatAssignment().setArrSeatValue(rowComboBox.getSelectedIndex(), columnComboBox.getSelectedIndex(), 1);
        
        
        
        
        
        JOptionPane.showMessageDialog(null, "Order Created Successfully");
        System.out.println(r);
        System.out.println();
        populate();
        
//        for(int a=0;a<arr.length;a++){//控制每个一维数组
//			for(int i=0;i<arr[a].length;i++){//控制每个一维数组中的元素
//				System.out.print(arr[a][i]+" ");//输出每个元素的值
//			}
//			System.out.println();//每执行完一个一维数组换行
//		}
    }//GEN-LAST:event_btnBookActionPerformed

    private void txtfltNumActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtfltNumActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtfltNumActionPerformed
    private void backAction() {
        rightPanel.remove(this);
        Component[] componentArray = rightPanel.getComponents();
        Component component = componentArray[componentArray.length - 1];
        FlightFoundJPanel ffjp = (FlightFoundJPanel) component;
        ffjp.populate();
        CardLayout layout = (CardLayout) rightPanel.getLayout();
        layout.previous(rightPanel);
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnBook;
    private javax.swing.JComboBox columnComboBox;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JComboBox rowComboBox;
    private javax.swing.JTable tblSeat;
    private javax.swing.JTextField txtRemainSeat;
    private javax.swing.JTextField txtfltNum;
    // End of variables declaration//GEN-END:variables
}
