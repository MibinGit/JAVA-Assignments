/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author minjian
 */
public class CustomerDirectory {
    
    private ArrayList<Customer> customerDirectory;
    
    public CustomerDirectory(){
        customerDirectory = new ArrayList<Customer>();
    }

    public ArrayList<Customer> getCustomerDirectory() {
        return customerDirectory;
    }

    public void setCustomerDirectory(ArrayList<Customer> customerDirectory) {
        this.customerDirectory = customerDirectory;
    }
    
    public Customer addCustomer(){
        Customer ctm = new Customer();
        customerDirectory.add(ctm);
        return ctm;
    }
    
    public void add(Customer ctm){
       customerDirectory.add(ctm);
        
    }
    public void removeCustomer(Customer ctm){
        customerDirectory.remove(ctm);
    }
    
    public Customer searchCustomer(String username){
        for(Customer ctm :customerDirectory){
            if(ctm.getUsername().equalsIgnoreCase(username)){
                return ctm;
            }
        }
        JOptionPane.showMessageDialog(null, "");
        return null;
    }
}
