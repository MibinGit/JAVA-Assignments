/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;

/**
 *
 * @author minjian
 */
public class Flight {
    private String flightNum;
    private String DepLoc;
    private String ArrLoc;
    private Date DepDate;
    private int datetype;
    private Date ArrDate;
    private Airplane airplane;
    private CustomerDirectory ctmDir;
    private SeatAssignment seatAssignment;
    
    public Flight(){
        ctmDir = new CustomerDirectory();
        seatAssignment = new SeatAssignment();
    }
    public String getFlightNum() {
        return flightNum;
    }

    public void setFlightNum(String flightNum) {
        this.flightNum = flightNum;
    }

    public String getDepLoc() {
        return DepLoc;
    }

    public void setDepLoc(String DepLoc) {
        this.DepLoc = DepLoc;
    }

    public String getArrLoc() {
        return ArrLoc;
    }

    public void setArrLoc(String ArrLoc) {
        this.ArrLoc = ArrLoc;
    }

    public Date getDepDate() {
        return DepDate;
    }

    public void setDepDate(Date DepDate) {
        this.DepDate = DepDate;
    }

    public Date getArrDate() {
        return ArrDate;
    }

    public void setArrDate(Date ArrDate) {
        this.ArrDate = ArrDate;
    }

    public int getDatetype() {
        return datetype;
    }

    public void setDatetype(int datetype) {
        this.datetype = datetype;
    }
    
    public Airplane getAirplane() {
        return airplane;
    }

    public void setAirplane(Airplane airplane) {
        this.airplane = airplane;
    }

    public CustomerDirectory getCtmDir() {
        return ctmDir;
    }

    public void setCtmDir(CustomerDirectory ctmDir) {
        this.ctmDir = ctmDir;
    }

    public SeatAssignment getSeatAssignment() {
        return seatAssignment;
    }

    public void setSeatAssignment(SeatAssignment seatAssignment) {
        this.seatAssignment = seatAssignment;
    }
    
    
    
     public Date dateDemo(String date){
       SimpleDateFormat ft = new SimpleDateFormat ("yyyy-MM-dd HH:mm");
       String input = date; 

       Date t =new Date(); 
        try { 
          t=ft.parse(input); 
          
        }catch (ParseException e) { 
          JOptionPane.showMessageDialog(null, "Please use the format: yyyy-MM-dd");
          
        }
       
        return t;
      }
      
//      public Date hourDemo(String time){
//       SimpleDateFormat ft= new SimpleDateFormat ("HH");
//       String input = time; 
//
//       Date t =new Date(); 
//        try { 
//          t = ft.parse(input); 
//          
//        }catch (ParseException e) { 
//          JOptionPane.showMessageDialog(null, "Please use the format: HH");
//        }
//        return t;
//      }
      
      public int datetypeDemo(Date date){
            SimpleDateFormat hh = new SimpleDateFormat ("HH");
            Date input = date;
          
            int dt;
            dt = Integer.parseInt(hh.format(date));
            if(dt <= 8){
                return 1; // 1-morning
            }else if(dt > 16){
                return 3; // 3-evening
            }else{
                return 2; // 2-day time
            }
      }

    @Override
    public String toString() {
        return flightNum;
    }
}
