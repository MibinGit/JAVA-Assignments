/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

/**
 *
 * @author minjian
 */
public class Airplane {
    private int airplaneNum;
    private String airplaneName;
    private String airplaneType;
    private int attendedtime;
    private Seat seat;
    private FlightDirectory flightDirectory;
    private Airliner airliner;

    public Airplane(){
        flightDirectory = new FlightDirectory();
    }
    public int getAirplaneNum() {
        return airplaneNum;
    }

    public void setAirplaneNum(int airplaneNum) {
        this.airplaneNum = airplaneNum;
    }

    public String getAirplaneName() {
        return airplaneName;
    }

    public void setAirplaneName(String airplaneName) {
        this.airplaneName = airplaneName;
    }

    public String getAirplaneType() {
        return airplaneType;
    }

    public void setAirplaneType(String airplaneType) {
        this.airplaneType = airplaneType;
    }

    public int getAttendedtime() {
        return attendedtime;
    }

    public void setAttendedtime(int attendedtime) {
        this.attendedtime = attendedtime;
    }

    public Seat getSeat() {
        return seat;
    }

    public void setSeat(Seat seat) {
        this.seat = seat;
    }

    public FlightDirectory getFlightDirectory() {
        return flightDirectory;
    }

    public void setFlightDirectory(FlightDirectory flightDirectory) {
        this.flightDirectory = flightDirectory;
    }

    public Airliner getAirliner() {
        return airliner;
    }

    public void setAirliner(Airliner airliner) {
        this.airliner = airliner;
    }
    
    
    

    @Override
    public String toString() {
        return airplaneName;
    }
    
    
}
