/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author minjian
 */
public class SeatAssignment {
    private final int row= 25;
    private final int column = 6;
    private final int seatNum = 150;
    private int remainSeat;
    private int[][] arrSeat;
    //private Seat seat;
    //private ArrayList<Seat> seatList;
    
    
    public SeatAssignment(){
       
        remainSeat = seatNum;
        arrSeat = new int[row][column];
//        seat = new Seat();
//        seatList= new ArrayList<Seat>();
    }

    public int getRemainSeat() {
        return remainSeat;
    }

    public void setRemainSeat(int remainSeat) {
        this.remainSeat = remainSeat;
    }

    public int[][] getArrSeat() {
        return arrSeat;
    }

    public void setArrSeat(int[][] arrSeat) {
        this.arrSeat = arrSeat;
    }
    
    public int  getArrSeatValue(int row,int column) {
        int i = arrSeat[row][column];
        return i;
    }

    public void setArrSeatValue(int row,int column,int i) {
        arrSeat[row][column] = i;
    }

//    public ArrayList<Seat> getSeatList() {
//        return seatList;
//    }
//
//    public void setSeatList(ArrayList<Seat> seatList) {
//        this.seatList = seatList;
//    }
//    
//    public Seat addSeat(){
//        Seat s = new Seat();
//        seatList.add(s);
//        return s;
//    }
//    
//    public void removeSeat(Seat s){
//        seatList.remove(s);
//    }
//    public void selectSeat(int row,int column){
//        
//        for(Seat seat : arrSeat){
//        if (arrSeat[row][column] == 0){
//        arrSeat[row][column] = 1;
//        remainSeat--;
//        
//        return seat;
//        }
//        }
//        JOptionPane.showMessageDialog(null, "This seat has been selected,please select another one.");
//        
//        
//        
//        return null;
//        
//    }

//    public Seat getSeat() {
//        return seat;
//    }
//
//    public void setSeat(Seat seat) {
//        this.seat = seat;
//    }
}
    
