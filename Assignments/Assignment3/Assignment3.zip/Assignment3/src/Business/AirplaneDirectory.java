/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author minjian
 */
public class AirplaneDirectory {
    
    private ArrayList<Airplane> airplaneDirectory;
    
    public AirplaneDirectory(){
        airplaneDirectory = new ArrayList<Airplane>();
    }

    public ArrayList<Airplane> getAirplaneDirectory() {
        return airplaneDirectory;
    }
    
    public Airplane getairplane(Airplane returnairplane){
        return returnairplane;
    }

    public void setAirplaneDirectory(ArrayList<Airplane> airplaneDirectory) {
        this.airplaneDirectory = airplaneDirectory;
    }
    
    public Airplane addairplane(){
        Airplane ap = new Airplane();
        airplaneDirectory.add(ap);
        return ap;
    }
    
    public void removeAirplane(Airplane ap){
        airplaneDirectory.remove(ap);
    }
    
    public Airplane searchAirplane(String airplaneName){
        for(Airplane ap :airplaneDirectory){
            if(ap.getAirplaneName().equalsIgnoreCase(airplaneName)){
                return ap;
            }
        }
        JOptionPane.showMessageDialog(null, "Airplane doesn't exist!");
        return null;
    }
}
