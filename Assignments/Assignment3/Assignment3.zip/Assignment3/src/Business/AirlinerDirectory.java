/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author minjian
 */
public class AirlinerDirectory {
      
    private ArrayList<Airliner> airlinerDirectory;
    
    public AirlinerDirectory(){
        airlinerDirectory = new ArrayList<Airliner>();
    }

    public ArrayList<Airliner> getAirlinerDirectory() {
        return airlinerDirectory;
    }

    public void setAirlinerDirectory(ArrayList<Airliner> airlinerDirectory) {
        this.airlinerDirectory = airlinerDirectory;
    }
    
    public Airliner addAirliner(){
        Airliner a = new Airliner();
        airlinerDirectory.add(a);
        return a;
    }
    
    public void removeAirliner(Airliner a){
        airlinerDirectory.remove(a);
    }
    
    public Airliner searchAirliner(String name){
        for(Airliner airliner : this.airlinerDirectory){
            if(airliner.getAirlinerName().equalsIgnoreCase(name)){
                return airliner;
            }
        }
        JOptionPane.showMessageDialog(null, "Airline Name doesn't exist!");
        return null;
        
    }
}

