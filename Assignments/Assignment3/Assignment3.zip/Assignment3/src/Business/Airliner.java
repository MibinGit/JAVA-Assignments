/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

/**
 *
 * @author minjian
 */


public class Airliner {
    private String airlinerName;
    private String address;
    private int airlinerID;
    private String desciption;
    private AirplaneDirectory  airplaneDirectory;
    
    public Airliner(){
        airplaneDirectory = new AirplaneDirectory();
    }

    public String getAirlinerName() {
        return airlinerName;
    }

    public void setAirlinerName(String airname) {
        this.airlinerName = airname;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getAirlinerID() {
        return airlinerID;
    }

    public void setAirlinerID(int airlinerID) {
        this.airlinerID = airlinerID;
    }

    public String getDesciption() {
        return desciption;
    }

    public void setDesciption(String desciption) {
        this.desciption = desciption;
    }
    
    
    public AirplaneDirectory getAirplaneDirectory() {
        return airplaneDirectory;
    }

    public void setAirplaneDirectory(AirplaneDirectory airplaneDirectory) {
        this.airplaneDirectory = airplaneDirectory;
    }
    
    
      @Override
    public String toString() {
        return airlinerName;
    }
}
