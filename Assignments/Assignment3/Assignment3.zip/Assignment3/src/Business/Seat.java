/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import javax.swing.JOptionPane;

/**
 *
 * @author minjian
 */
public class Seat {
    private int row;
    private int column;
    private int remainSeat;
    private String seatPosition;
    private int seatState;

    public Seat(){
        
        //arrSeat = new int[25][6];
        //seatPosition = String.valueOf(column) + String.valueOf(row);
    }

    public int getRow() {
        return row;
    }

    public void setRow(int row) {
        this.row = row;
    }

    public int getColumn() {
        return column;
    }

    public void setColumn(int column) {
        this.column = column;
    }

   

//    public int[][] getArrSeat() {
//        return arrSeat;
//    }
//
//    public void setArrSeat(int[][] arrSeat) {
//        this.arrSeat = arrSeat;
//    }

    public int getRemainSeat() {
        return remainSeat;
    }

    public void setRemainSeat(int remainSeat) {
        this.remainSeat = remainSeat;
    }

    public String getSeatPosition() {
        return seatPosition;
    }

    public void setSeatPosition(String seatPosition) {
        this.seatPosition = seatPosition;
    }

    public int getSeatState() {
        return seatState;
    }

    public void setSeatState(int seatState) {
        this.seatState = seatState;
    }
    
//    public Seat selectSeat(int row,int column){
//        
//        seatPosition = String.valueOf(column) + String.valueOf(row);
//        if (arrSeat[row][column] == 0){
//        arrSeat[row][column] = 1;
//        remainSeat--;
//        
//        }else{
//        JOptionPane.showMessageDialog(null, "This seat has been selected,please select another one.");
//        
//    }

    @Override
    public String toString() {
        return seatPosition;
    }
        
        
    
        
  
    
    
    
    

       
}

