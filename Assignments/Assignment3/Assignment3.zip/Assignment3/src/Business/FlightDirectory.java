/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author minjian
 */
public class FlightDirectory {
    
    private ArrayList<Flight> flightDirectory;
    
    public FlightDirectory(){
        flightDirectory = new ArrayList<Flight>();
    }

    public ArrayList<Flight> getFlightDirectory() {
        return flightDirectory;
    }

    public void setFlightDirectory(ArrayList<Flight> flightDirectory) {
        this.flightDirectory = flightDirectory;
    }
    
    public Flight addflight(){
        Flight f = new Flight();
        flightDirectory.add(f);
        return f;
    }
    
    public void add(Flight f){
        flightDirectory.add(f);
    }
    public void removeFlight(Flight f){
        flightDirectory.remove(f);
    }
    
//    public List<Flight> getSearchResult(String flightNum,String depLoc,String arrLoc,String depDate,int dateType){
//        List<Flight> searchResultList = new ArrayList<>();
//        SimpleDateFormat ymd = new SimpleDateFormat ("yyyy-MM-dd");
//        
//        
//        
//        
//        if(flightNum.isEmpty()){
//            if(depLoc.isEmpty()){
//                if(arrLoc.isEmpty()){
//                    if(depDate.isEmpty()){
//                        if(dateType == 0){
//                            for(Flight f : flightDirectory){
//                                    searchResultList.add(f);
//                            }
//                        }else{
//                            for(Flight f : flightDirectory){
//                                if(f.getDatetype() == dateType){
//                                    searchResultList.add(f); 
//                                }
//                            }
//                            
//                        }
//                    }else{
//                        if(dateType == 0){
//                            for(Flight f : flightDirectory){
//                                if(ymd.format(f.getDepDate()).equalsIgnoreCase(depDate)){
//                                    searchResultList.add(f); 
//                                }
//                            }
//                            
//                        }else{
//                            for(Flight f : flightDirectory){
//                                if(ymd.format(f.getDepDate()).equalsIgnoreCase(depDate) && f.getDatetype() == dateType){
//                                    searchResultList.add(f); 
//                                }
//                            }
//                            
//                        }
//                    }
//                }else{
//                    if(depDate.isEmpty()){
//                        if(dateType == 0){
//                            for(Flight f : flightDirectory){
//                                if(f.getArrLoc().equalsIgnoreCase(arrLoc)){
//                                    searchResultList.add(f); 
//                                }
//                            }
//                            
//                        }else{
//                            for(Flight f : flightDirectory){
//                                if(f.getArrLoc().equalsIgnoreCase(arrLoc) && f.getDatetype() == dateType){
//                                    searchResultList.add(f); 
//                                }
//                            }
//                            
//                        }
//                    }else{
//                        if(dateType == 0){
//                            for(Flight f : flightDirectory){
//                                if(f.getArrLoc().equalsIgnoreCase(arrLoc) && ymd.format(f.getDepDate()).equalsIgnoreCase(depDate)){
//                                    searchResultList.add(f); 
//                                }
//                            }
//                            
//                        }else{
//                            for(Flight f : flightDirectory){
//                                if(f.getArrLoc().equalsIgnoreCase(arrLoc) && ymd.format(f.getDepDate()).equalsIgnoreCase(depDate) && f.getDatetype() == dateType){
//                                    searchResultList.add(f); 
//                                }
//                            }
//                            
//                        }
//                    }
//                }
//            }else{
//                if(arrLoc.isEmpty()){
//                    if(depDate.isEmpty()){
//                        if(dateType == 0){
//                            for(Flight f : flightDirectory){
//                                if(f.getDepLoc().equalsIgnoreCase(depLoc)){
//                                    searchResultList.add(f); 
//                                }
//                            }
//                            
//                        }
//                        }else{
//                            for(Flight f : flightDirectory){
//                                if(f.getDepLoc().equalsIgnoreCase(depLoc) && f.getDatetype() == dateType){
//                                    searchResultList.add(f); 
//                                }
//                            }
//                            
//                        }
//                    }else{
//                        if(dateType == 0){
//                            for(Flight f : flightDirectory){
//                                if(f.getDepLoc().equalsIgnoreCase(depLoc) && ymd.format(f.getDepDate()).equalsIgnoreCase(depDate)){
//                                    searchResultList.add(f); 
//                                }
//                            }
//                            
//                        }else{
//                            for(Flight f : flightDirectory){
//                                if(f.getDepLoc().equalsIgnoreCase(depLoc) && ymd.format(f.getDepDate()).equalsIgnoreCase(depDate) && f.getDatetype() == dateType){
//                                    searchResultList.add(f); 
//                                }
//                            }
//                            
//                        }
//                    }
//                }   
//        }else{
//            if(depLoc.isEmpty()){
//                if(arrLoc.isEmpty()){
//                    if(depDate.isEmpty()){
//                        if(dateType == 0){
//                            for(Flight f : flightDirectory){
//                                if(f.getFlightNum().equalsIgnoreCase(flightNum)){
//                                    searchResultList.add(f); 
//                                }
//                            }
//                            
//                        }else{
//                            for(Flight f : flightDirectory){
//                                if(f.getFlightNum().equalsIgnoreCase(flightNum) && f.getDatetype() == dateType){
//                                    searchResultList.add(f); 
//                                }
//                            }
//                            
//                        }
//                    }else{
//                        if(dateType == 0){
//                            for(Flight f : flightDirectory){
//                                if(f.getFlightNum().equalsIgnoreCase(flightNum) && ymd.format(f.getDepDate()).equalsIgnoreCase(depDate)){
//                                    searchResultList.add(f); 
//                                }
//                            }
//                            
//                        }else{
//                            for(Flight f : flightDirectory){
//                                if(f.getFlightNum().equalsIgnoreCase(flightNum) && ymd.format(f.getDepDate()).equalsIgnoreCase(depDate) && f.getDatetype() == dateType){
//                                    searchResultList.add(f); 
//                                }
//                            }
//                            
//                        }
//                    }
//                }else{
//                    if(depDate.isEmpty()){
//                        if(dateType == 0){
//                            for(Flight f : flightDirectory){
//                                if(f.getFlightNum().equalsIgnoreCase(flightNum) && f.getArrLoc().equalsIgnoreCase(arrLoc)){
//                                    searchResultList.add(f); 
//                                }
//                            }
//                            
//                        }else{
//                            for(Flight f : flightDirectory){
//                                if(f.getFlightNum().equalsIgnoreCase(flightNum) && f.getArrLoc().equalsIgnoreCase(arrLoc) && f.getDatetype() == dateType){
//                                    searchResultList.add(f); 
//                                }
//                            }
//                            
//                        }
//                    }else{
//                        if(dateType == 0){
//                            for(Flight f : flightDirectory){
//                                if(f.getFlightNum().equalsIgnoreCase(flightNum) && f.getArrLoc().equalsIgnoreCase(arrLoc) && ymd.format(f.getDepDate()).equalsIgnoreCase(depDate)){
//                                    searchResultList.add(f); 
//                                }
//                            }
//                            
//                        }else{
//                            for(Flight f : flightDirectory){
//                                if(f.getFlightNum().equalsIgnoreCase(flightNum) && f.getArrLoc().equalsIgnoreCase(arrLoc) && ymd.format(f.getDepDate()).equalsIgnoreCase(depDate) && f.getDatetype() == dateType){
//                                    searchResultList.add(f); 
//                                }
//                            }
//                            
//                        }
//                    }
//                }
//            }else{
//                if(arrLoc.isEmpty()){
//                    if(depDate.isEmpty()){
//                        if(dateType == 0){
//                            for(Flight f : flightDirectory){
//                                if(f.getFlightNum().equalsIgnoreCase(flightNum) && f.getDepLoc().equalsIgnoreCase(depLoc)){
//                                    searchResultList.add(f); 
//                                }
//                            }
//                            
//                        }
//                        }else{
//                            for(Flight f : flightDirectory){
//                                if(f.getFlightNum().equalsIgnoreCase(flightNum) && f.getDepLoc().equalsIgnoreCase(depLoc) && f.getDatetype() == dateType){
//                                    searchResultList.add(f); 
//                                }
//                            }
//                            
//                        }
//                    }else{
//                        if(dateType == 0){
//                            for(Flight f : flightDirectory){
//                                if(f.getFlightNum().equalsIgnoreCase(flightNum) && f.getDepLoc().equalsIgnoreCase(depLoc) && ymd.format(f.getDepDate()).equalsIgnoreCase(depDate)){
//                                    searchResultList.add(f); 
//                                }
//                            }
//                            
//                        }else{
//                            for(Flight f : flightDirectory){
//                                if(f.getFlightNum().equalsIgnoreCase(flightNum) && f.getDepLoc().equalsIgnoreCase(depLoc) && ymd.format(f.getDepDate()).equalsIgnoreCase(depDate) && f.getDatetype() == dateType){
//                                    searchResultList.add(f); 
//                                }
//                            }
//                            
//                        }
//                    }
//                }   
//        }        
////    for(Flight f : flightDirectory){
////            if(f.getFlightNum().equalsIgnoreCase(flightNum) && f.getDepLoc().equalsIgnoreCase(depLoc) && f.getArrLoc().equalsIgnoreCase(arrLoc)
////                   && ymd.format(f.getDepDate()).equalsIgnoreCase(depDate) &&  f.getDatetype() == dateType){
////                searchResultList.add(f); 
////            }
////        }
////        return searchResultList;
//        
//    return searchResultList;       
//} 
//    
//    public Flight searchFlight(String flightNum,String DepLoc,String ArrLoc,Date DepDate){
//        for(Flight f : flightDirectory){
//            if(f.getFlightNum().equalsIgnoreCase(flightNum)){
//                return f;
//            }
//        }
//        JOptionPane.showMessageDialog(null, "Flight doesn't exist!");
//        return null;
//        
//    }
//    
//    
    
}
